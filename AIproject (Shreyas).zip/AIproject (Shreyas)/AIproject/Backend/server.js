const express = require("express");
const axios = require("axios");
const cors = require("cors");
const ExcelJS = require("exceljs");
const fs = require("fs");
const path = require("path");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const dotenv = require("dotenv");
const OpenAI = require("openai");
const auth = require("./middleware/auth");
const User = require("./models/User");

dotenv.config();

// Initialize AI provider (OpenAI only)
const openai = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;
const app = express();
app.use(cors());
app.use(express.json());

// 🔗 MongoDB Connection
const connectDB = async () => {
  try {
    if (!process.env.MONGO_URI) {
      throw new Error("MONGO_URI is not defined in environment variables");
    }

    await mongoose.connect(process.env.MONGO_URI, {
      serverSelectionTimeoutMS: 30000, // 30 seconds
      connectTimeoutMS: 30000,
      socketTimeoutMS: 45000,
      retryWrites: true,
      w: 'majority',
      // Add these options to help with Atlas connectivity
      maxPoolSize: 10,
      minPoolSize: 1,
    });

    console.log("✅ MongoDB connected successfully");

    // Handle connection events
    mongoose.connection.on('error', (err) => {
      console.error('❌ MongoDB connection error:', err);
    });

    mongoose.connection.on('disconnected', () => {
      console.warn('⚠️ MongoDB disconnected');
    });

    mongoose.connection.on('reconnected', () => {
      console.log('✅ MongoDB reconnected');
    });

  } catch (err) {
    console.error("❌ MongoDB connection error:", err.message);
    
    // Provide helpful error messages
    if (err.message.includes('ENOTFOUND') || err.message.includes('getaddrinfo')) {
      console.error("\n💡 Troubleshooting tips:");
      console.error("   1. Check your internet connection");
      console.error("   2. Verify your MONGO_URI in the .env file");
    } else if (err.message.includes('authentication') || err.message.includes('credentials')) {
      console.error("\n💡 Troubleshooting tips:");
      console.error("   1. Check your MongoDB username and password in MONGO_URI");
      console.error("   2. Make sure special characters in password are URL-encoded");
    } else if (err.name === 'MongooseServerSelectionError') {
      console.error("\n💡 Troubleshooting tips:");
      console.error("   1. Your IP address may not be whitelisted in MongoDB Atlas");
      console.error("   2. Go to MongoDB Atlas → Network Access → Add IP Address");
      console.error("   3. Add 0.0.0.0/0 (allow all) for development, or your specific IP");
      console.error("   4. Wait 1-2 minutes after adding IP for changes to take effect");
      console.error("   5. Verify your connection string includes the correct database name");
    }
    
    // Exit process if connection fails (optional - remove if you want app to continue)
    // process.exit(1);
  }
};

// Connect to database before starting server
connectDB();

// Middleware to check MongoDB connection before database operations
const checkDBConnection = (req, res, next) => {
  if (mongoose.connection.readyState !== 1) {
    return res.status(503).json({ 
      error: "Database not connected. Please wait for the connection to be established.",
      status: mongoose.connection.readyState === 0 ? "disconnected" : 
              mongoose.connection.readyState === 2 ? "connecting" : "disconnecting"
    });
  }
  next();
};

// 🟢 Root route
app.get("/", (req, res) => res.send("Server is running ✅"));

// 🟣 Register
app.post("/api/register", checkDBConnection, async (req, res) => {
  try {
    const { name, email, phone, password } = req.body;
    if (!password || (!email && !phone))
      return res.status(400).json({ error: "Email or phone and password required" });

    const existingUser = await User.findOne({ $or: [{ email }, { phone }] });
    if (existingUser) return res.status(400).json({ error: "User already exists" });

    const hashed = await bcrypt.hash(password, 10);
    const user = new User({ name, email, phone, password: hashed });
    await user.save();

    res.json({ message: "User registered successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
});

// 🟣 Login
app.post("/api/login", checkDBConnection, async (req, res) => {
  try {
    const { email, phone, password } = req.body;
    const user = await User.findOne({ $or: [{ email }, { phone }] });
    if (!user) return res.status(400).json({ error: "User not found" });

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(400).json({ error: "Invalid password" });

    const token = jwt.sign(
      { id: user._id, email: user.email, phone: user.phone },
      process.env.JWT_SECRET,
      { expiresIn: "2h" }
    );

    res.json({ message: "Login successful", token, user });
  } catch (err) {
    res.status(500).json({ error: "Login failed" });
  }
});

// 🟢 Fetch Stock Data (Protected)
app.get("/api/stock/:ticker", auth, async (req, res) => {
  const ticker = req.params.ticker.toUpperCase();
  const days = parseInt(req.query.days) || 50;

  try {
    // Fetch full name
    let fullName = ticker;
    try {
      const infoUrl = `https://query1.finance.yahoo.com/v7/finance/quote?symbols=${ticker}`;
      const infoResponse = await axios.get(infoUrl);
      const quoteData = infoResponse.data?.quoteResponse?.result?.[0];
      if (quoteData)
        fullName =
          quoteData.longName ||
          quoteData.shortName ||
          quoteData.displayName ||
          quoteData.symbol ||
          ticker;
    } catch {
      console.warn("⚠️ Could not fetch full name");
    }

    // Fetch price history
    const chartUrl = `https://query1.finance.yahoo.com/v8/finance/chart/${ticker}?range=1y&interval=1d`;
    const response = await axios.get(chartUrl, {
      headers: { "User-Agent": "Mozilla/5.0", Accept: "application/json" },
      timeout: 10000,
    });

    const chart = response?.data?.chart;
    if (!chart || chart.error)
      return res.status(400).json({ error: "Error fetching price data." });

    const result = chart.result?.[0];
    if (!result) return res.status(404).json({ error: "No price data found." });

    const quote = result?.indicators?.quote?.[0];
    const closes = quote?.close?.filter((c) => c !== null) || [];
    const highs = quote?.high?.filter((h) => h !== null) || [];
    const lows = quote?.low?.filter((l) => l !== null) || [];
    const timestamps = result?.timestamp || [];

    if (closes.length < days + 1)
      return res.status(400).json({ error: `Not enough data for ${days}-day average.` });

    const lastIndex = closes.length - 1;
    const avg = closes.slice(-(days + 1), -1).reduce((a, b) => a + b, 0) / days;
    const yesterdayClose = closes[lastIndex];
    const yesterdayHigh = highs[lastIndex];
    const yesterdayLow = lows[lastIndex];
    const yesterdayDate = new Date(timestamps[lastIndex] * 1000)
      .toISOString()
      .split("T")[0];

    const diff = yesterdayClose - avg;
    const adj = Math.abs(diff) * 0.5;
    const support = yesterdayClose - adj;
    const resistance = yesterdayClose + adj;

    res.json({
      ticker,
      fullName,
      avg,
      close: yesterdayClose,
      high: yesterdayHigh,
      low: yesterdayLow,
      diff,
      adj,
      support,
      resistance,
      date_close: yesterdayDate,
      date_high: yesterdayDate,
      date_low: yesterdayDate,
      days,
    });
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch stock data" });
  }
});

// 🟢 Export Excel
app.post("/api/export", auth, async (req, res) => {
  try {
    const {
      ticker,
      fullName,
      avg,
      close,
      diff,
      adj,
      support,
      resistance,
      high,
      low,
      date_close,
      date_high,
      date_low,
      days,
    } = req.body;

    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Stock Report");

    sheet.mergeCells("A1", "B1");
    sheet.getCell("A1").value = `${fullName} (${ticker}) Report`;
    sheet.getCell("A1").font = { bold: true, size: 14 };
    sheet.getCell("A1").alignment = { horizontal: "center" };

    const rows = [
      ["Date (Close)", date_close],
      ["Date (High)", date_high],
      ["Date (Low)", date_low],
      [`${days}-Day Average`, avg],
      ["Yesterday's Close", close],
      ["Yesterday's High", high],
      ["Yesterday's Low", low],
      ["Total Difference", diff],
      ["50% Adjustment", adj],
      ["Support Level", support],
      ["Resistance Level", resistance],
    ];

    sheet.addRows(rows);
    sheet.columns.forEach((col) => {
      let max = 0;
      col.eachCell({ includeEmpty: true }, (cell) => {
        max = Math.max(max, cell.value ? cell.value.toString().length : 10);
      });
      col.width = max + 2;
    });

    const filePath = path.join(__dirname, `${ticker}_report.xlsx`);
    await workbook.xlsx.writeFile(filePath);
    res.download(filePath, `${ticker}_report.xlsx`, (err) => {
      if (!err) fs.unlinkSync(filePath);
    });
  } catch (err) {
    res.status(500).json({ error: "Failed to export Excel file" });
  }
});

// 🟢 Fetch Stock News via AI (Protected)
app.get("/api/stock/:ticker/news", auth, async (req, res) => {
  const ticker = req.params.ticker.toUpperCase();

  try {
    if (!openai) {
      return res.status(503).json({ 
        error: "OPENAI_API_KEY is not configured in Backend/.env."
      });
    }

    // Fetch stock full name
    let fullName = ticker;
    try {
      const infoUrl = `https://query1.finance.yahoo.com/v7/finance/quote?symbols=${ticker}`;
      const infoResponse = await axios.get(infoUrl);
      const quoteData = infoResponse.data?.quoteResponse?.result?.[0];
      if (quoteData)
        fullName =
          quoteData.longName ||
          quoteData.shortName ||
          quoteData.displayName ||
          quoteData.symbol ||
          ticker;
    } catch (err) {
      console.warn("⚠️ Could not fetch full name:", err.message);
    }

    // Build a comprehensive prompt for stock news analysis
    const prompt = `You are a financial analyst. Analyze and provide recent important news, events, and developments that are likely to affect the stock value of ${fullName} (${ticker}).

Focus on:
1. Recent company announcements (earnings, product launches, partnerships)
2. Industry trends and market conditions
3. Economic indicators relevant to this stock
4. Analyst recommendations and sentiment
5. Regulatory changes or legal developments
6. Competitive landscape changes

Provide a structured analysis with:
- A brief summary (2-3 sentences)
- Key events/developments (3-5 bullet points)
- Potential impact on stock price (positive/negative/neutral)

Format your response as a JSON object with this structure:
{
  "summary": "brief 2-3 sentence summary",
  "events": ["event 1", "event 2", "event 3"],
  "impact": "positive/negative/neutral",
  "recommendation": "brief recommendation"
}

Current date: ${new Date().toLocaleDateString()}`;

    let text;
    try {
      const model = process.env.OPENAI_MODEL || "gpt-4o-mini";
      const completion = await openai.chat.completions.create({
        model,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: "You are a concise financial news analyst that outputs strict JSON." },
          { role: "user", content: prompt }
        ],
        temperature: 0.4,
      });
      text = completion.choices?.[0]?.message?.content || "";

      if (!text || text.trim().length === 0) {
        throw new Error("Empty response from AI provider");
      }
    } catch (aiErr) {
      console.error("AI call error:", aiErr);
      throw aiErr;
    }

    // Try to parse JSON from the response
    let newsData;
    try {
      // Extract JSON from markdown code blocks if present
      const jsonMatch = text.match(/```json\s*([\s\S]*?)\s*```/) || text.match(/```\s*([\s\S]*?)\s*```/);
      const jsonText = jsonMatch ? jsonMatch[1] : text.trim();
      
      // Try to find JSON object in the text
      const jsonObjectMatch = jsonText.match(/\{[\s\S]*\}/);
      if (jsonObjectMatch) {
        newsData = JSON.parse(jsonObjectMatch[0]);
      } else {
        throw new Error("No JSON object found in response");
      }
      
      // Ensure required fields exist
      if (!newsData.summary) newsData.summary = text.substring(0, 300);
      if (!newsData.events || !Array.isArray(newsData.events)) {
        newsData.events = text.split('\n')
          .filter(line => line.trim().startsWith('-') || line.trim().match(/^\d+\./) || line.trim().startsWith('*'))
          .slice(0, 5)
          .map(line => line.replace(/^[-*\d.]+\s*/, '').trim())
          .filter(line => line.length > 0);
      }
      if (!newsData.impact) newsData.impact = "neutral";
      if (!newsData.recommendation) newsData.recommendation = "Review the provided information";
      
    } catch (parseError) {
      console.warn("JSON parsing failed, using fallback format. Error:", parseError.message);
      console.warn("Raw response text:", text.substring(0, 200));
      
      // If parsing fails, return the raw text in a structured format
      const lines = text.split('\n').filter(line => line.trim().length > 0);
      newsData = {
        summary: lines.slice(0, 3).join(' ') || text.substring(0, 300) || "Analysis available but formatting needs review.",
        events: lines
          .filter(line => line.trim().startsWith('-') || line.trim().match(/^\d+\./) || line.trim().startsWith('*'))
          .slice(0, 5)
          .map(line => line.replace(/^[-*\d.]+\s*/, '').trim())
          .filter(line => line.length > 0),
        impact: text.toLowerCase().includes('postive') ? "postive" : 
                text.toLowerCase().includes('negative') ? "negative" : "neutral",
        recommendation: lines.find(line => line.toLowerCase().includes('recommend')) || 
                       lines.find(line => line.toLowerCase().includes('suggest')) ||
                       "Review the provided information"
      };
    }

    res.json({
      ticker,
      fullName,
      ...newsData,
      timestamp: new Date().toISOString()
    });
  } catch (err) {
    console.error("❌ Stock News API error:", err);
    console.error("Error stack:", err.stack);
    
    // Provide helpful error messages
    let errorMessage = "Failed to fetch news. Please try again later.";
    let statusCode = 500;
    
    if (err.response) {
      // Error from AI provider (OpenAI)
      const status = err.response.status;
      if (status === 401 || status === 403) {
        errorMessage = "Invalid or unauthorized AI API key. Please check OPENAI_API_KEY.";
        statusCode = 401;
      } else if (status === 404) {
        errorMessage = "AI model not found. Verify OPENAI_MODEL.";
        statusCode = 404;
      } else if (status === 429) {
        errorMessage = "AI API rate limit exceeded. Please try again later.";
        statusCode = 429;
      }
    } else if (err.message) {
      if (err.message.includes("404")) {
        errorMessage = "AI model not found. Verify OPENAI_MODEL.";
      } else if (err.message.includes("401") || err.message.includes("403")) {
        errorMessage = "Invalid or unauthorized AI API key. Please check OPENAI_API_KEY.";
      } else if (err.message.includes("429")) {
        errorMessage = "AI API rate limit exceeded. Please try again later.";
      } else if (err.message.includes("Empty response")) {
        errorMessage = "Received empty response from AI provider. Please try again.";
      }
    }
    
    res.status(statusCode).json({ 
      error: errorMessage,
      details: err.message || "Unknown error occurred"
    });
  }
});

// 🚀 Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`✅ Server running on http://localhost:${PORT}`));
