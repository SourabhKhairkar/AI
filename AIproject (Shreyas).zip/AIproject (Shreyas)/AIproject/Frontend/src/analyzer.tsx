import React, { useState } from "react";
import axios from "axios";
import "./App.css";

interface StockData {
  fullName: string;
  avg: number;
  close: number;
  diff: number;
  adj: number;
  support: number;
  resistance: number;
  high: number;
  low: number;
  date_close: string;
  date_high: string;
  date_low: string;
}

interface NewsData {
  summary: string;
  events: string[];
  impact: string;
  recommendation: string;
  timestamp: string;
}

const Analyzer: React.FC = () => {
  const [ticker, setTicker] = useState<string>("");
  const [data20, setData20] = useState<StockData | null>(null);
  const [data50, setData50] = useState<StockData | null>(null);
  const [dataSelected, setDataSelected] = useState<StockData | null>(null);
  const [selectedView, setSelectedView] = useState<'20' | '50' | 'other'>('20');
  const [newsData, setNewsData] = useState<NewsData | null>(null);
  const [loading, setLoading] = useState(false);
  const [newsLoading, setNewsLoading] = useState(false);
  const [error, setError] = useState<string>("");
  const [newsError, setNewsError] = useState<string>("");
  const [selectedDays, setSelectedDays] = useState<number>(100);

  const userName = localStorage.getItem("name");

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("name");
    window.location.href = "/login";
  };

  const fetchNews = async (stockTicker: string) => {
    setNewsLoading(true);
    setNewsError("");
    try {
      const token = localStorage.getItem("token");
      const response = await axios.get(
        `http://localhost:5000/api/stock/${stockTicker}/news`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setNewsData({
        summary: response.data.summary,
        events: response.data.events || [],
        impact: response.data.impact,
        recommendation: response.data.recommendation,
        timestamp: response.data.timestamp,
      });
      setNewsError(""); // Clear any previous errors
    } catch (err: any) {
      console.error("Error fetching news:", err);
      console.error("Error response:", err.response?.data);
      console.error("Error status:", err.response?.status);
      
      // Get detailed error message
      let errorMessage = "Failed to fetch news. Please try again.";
      if (err.response?.data?.error) {
        errorMessage = err.response.data.error;
        if (err.response.data.details) {
          errorMessage += ` (${err.response.data.details})`;
        }
      } else if (err.message) {
        errorMessage = err.message;
      } else if (err.response?.status === 500) {
        errorMessage = "Server error occurred. Please check your backend logs or try again later.";
      } else if (err.response?.status === 401) {
        errorMessage = "Authentication failed. Please log in again.";
      } else if (err.response?.status === 503) {
        errorMessage = "Service unavailable. Please check your AI API configuration (OPENAI_API_KEY).";
      }
      
      setNewsError(errorMessage);
      // Still show the section but with error message
    }
    setNewsLoading(false);
  };

  const handleAnalyze = async () => {
    if (!ticker.trim()) {
      setError("Please enter a stock ticker.");
      return;
    }

    setLoading(true);
    setError("");
    setNewsError("");
    setData20(null);
    setData50(null);
    setDataSelected(null);
    setNewsData(null);

    try {
      const normalize = (r: any): StockData => {
        const {
          fullName,
          avg,
          close,
          diff,
          adj,
          support,
          high,
          low,
          resistance,
          date_close,
          date_high,
          date_low,
        } = r.data;
        return { fullName, avg, close, diff, adj, support, high, low, resistance, date_close, date_high, date_low };
      };

      if (selectedView === '20') {
        const resp20 = await axios.get(`http://localhost:5000/api/stock/${ticker}?days=20`);
        setData20(normalize(resp20));
      } else if (selectedView === '50') {
        const resp50 = await axios.get(`http://localhost:5000/api/stock/${ticker}?days=50`);
        setData50(normalize(resp50));
      } else {
        const respSel = await axios.get(`http://localhost:5000/api/stock/${ticker}?days=${selectedDays}`);
        setDataSelected(normalize(respSel));
      }

      // Fetch news once
      await fetchNews(ticker);
    } catch (err) {
      setError("Error fetching stock data. Check ticker symbol.");
    }

    setLoading(false);
  };

  const handleExport = async () => {
    const exportData = selectedView === '20' ? data20 : selectedView === '50' ? data50 : dataSelected;
    const exportDays = selectedView === '20' ? 20 : selectedView === '50' ? 50 : selectedDays;
    if (!exportData) return;
    try {
      const response = await axios.post(
        "http://localhost:5000/api/export",
        { ...exportData, ticker, days: exportDays },
        { responseType: "blob" }
      );

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `${ticker}_report.xlsx`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (err) {
      alert("Failed to export report.");
    }
  };

  return (
    <div className="app-container">
      <header className="header">
        <h2>📊 Stock Level Analyzer</h2>
        <div className="user-info">
          <span>Welcome, {userName}</span>
          <button onClick={handleLogout}>Logout</button>
        </div>
      </header>

      <div className="input-section controls">
        <div className="control-row">
          <div className="control-group">
            <label htmlFor="ticker" className="control-label"> Ticker Name</label>
            <input
              id="ticker"
              type="text"
              placeholder="e.g. AAPL"
              value={ticker}
              onChange={(e) => setTicker(e.target.value.toUpperCase())}
              className="control-input"
              inputMode="text"
              autoCapitalize="characters"
              autoCorrect="off"
            />
            <button className="btn btn-outline" onClick={handleAnalyze} disabled={loading}>
              {loading ? "Analyzing..." : "Analyze"}
            </button>
          </div>
        </div>

        <div className="control-row">
          <div className="control-group">
            <button
              type="button"
              className={`btn ${selectedView === '20' ? 'btn-primary' : 'btn-ghost'}`}
              onClick={() => { setSelectedView('20'); handleAnalyze(); }}
              disabled={loading}
            >
              20-Day Average
            </button>
            <button
              type="button"
              className={`btn ${selectedView === '50' ? 'btn-primary' : 'btn-ghost'}`}
              onClick={() => { setSelectedView('50'); handleAnalyze(); }}
              disabled={loading}
            >
              50-Day Average
            </button>
          </div>

          <div className="control-group">
            <label htmlFor="other-ma" className="control-label">Other</label>
            <select
              id="other-ma"
              value={selectedDays}
              onChange={(e) => { setSelectedDays(Number(e.target.value)); setSelectedView('other'); handleAnalyze(); }}
              className="dropdown control-input"
            >
              <option value={100}>100-Day</option>
              <option value={200}>200-Day</option>
            </select>
          </div>

        </div>
      </div>

      {error && <p className="error">{error}</p>}

      {(data20 || data50 || dataSelected) && (
        <div className="results">
          {(() => {
            const d = selectedView === '20' ? data20 : selectedView === '50' ? data50 : dataSelected;
            const label = selectedView === '20' ? '20' : selectedView === '50' ? '50' : `${selectedDays}`;
            if (!d) return null;
            return (
              <>
                <h2>
                  {d.fullName} <span style={{ color: "#555" }}>({ticker})</span>
                </h2>
                <table>
                  <tbody>
                    <tr><td>{label}-Day Average:</td><td>${d.avg.toFixed(2)}</td></tr>
                    <tr><td>Today's Price:</td><td>${d.close.toFixed(2)}</td></tr>
                    <tr><td>High ({d.date_high}):</td><td>${d.high.toFixed(2)}</td></tr>
                    <tr><td>Low ({d.date_low}):</td><td>${d.low.toFixed(2)}</td></tr>
                    <tr><td>Difference:</td><td>${d.diff.toFixed(2)}</td></tr>
                    <tr className="support"><td>Support:</td><td>${d.support.toFixed(2)}</td></tr>
                    <tr className="resistance"><td>Resistance:</td><td>${d.resistance.toFixed(2)}</td></tr>
                  </tbody>
                </table>
              </>
            );
          })()}

          <button className="export-btn" onClick={handleExport}>📊 Export Report</button>
        </div>
      )}

      {/* News Section - Always show when there's data or loading, or after an error */}
      {(newsLoading || newsData || newsError) && (
        <div className="news-section">
          {newsLoading ? (
            <div className="news-loading">
              <div className="spinner"></div>
              <p>Fetching real-time news and analysis...</p>
            </div>
          ) : newsError ? (
            <div>
              <div className="news-header">
                <h3>📰 Real-Time Market Analysis</h3>
              </div>
              <div className="news-error">
                <p>⚠️ {newsError}</p>
                <button className="refresh-news-btn" onClick={() => fetchNews(ticker)}>
                  🔄 Try Again
                </button>
              </div>
            </div>
          ) : newsData ? (
            <>
              <div className="news-header">
                <h3>📰 Real-Time Market Analysis</h3>
                <span className={`news-badge news-badge-${newsData.impact.toLowerCase()}`}>
                  {newsData.impact}
                </span>
              </div>
              
              <div className="news-summary">
                <p>{newsData.summary}</p>
              </div>

              {newsData.events && newsData.events.length > 0 && (
                <div className="news-events">
                  <h4>Key Events & Developments</h4>
                  <ul>
                    {newsData.events.map((event, index) => (
                      <li key={index}>{event}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="news-recommendation">
                <h4>Recommendation</h4>
                <p>{newsData.recommendation}</p>
              </div>

              {newsData.timestamp && (
                <div className="news-timestamp">
                  <small>Last updated: {new Date(newsData.timestamp).toLocaleString()}</small>
                </div>
              )}

              <button className="refresh-news-btn" onClick={() => fetchNews(ticker)}>
                🔄 Refresh News
              </button>
            </>
          ) : null}
        </div>
      )}
    </div>
  );
};

export default Analyzer;
